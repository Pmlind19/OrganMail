
public class Exercise01_08 {

	public static void main(String[] args)
	{
		double radius = 5.5;
		System.out.println("The perimeter of a circle with a radius of 5.5 is " + 2 * radius * 3.14);
		System.out.println("The area of a circle with a radius of 5.5 is " + radius * radius * 3.14);
		
	}

}
