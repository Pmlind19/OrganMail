
public class Exercise01_09 {

	public static void main(String[] args) 
	{
		System.out.println("The area of a rectangle with a width of 4.5 and a height of 7.9 is " + 4.5 * 7.9);

	}

}
