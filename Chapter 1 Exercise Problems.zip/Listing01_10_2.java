
public class Listing01_10_2 {

	public static void main(String[] args) {
		// This is to show Runtime Errors
		System.out.println(1/0);

	}

}
