
public class Listing01_10_3 {

	public static void main(String[] args) {
		// This is to show Logic Errors
		System.out.println("Celsius 35 is Fahrenheit degree ");
		System.out.println((9 / 5) * 32 + 35);

	}

}
