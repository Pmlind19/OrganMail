
public class Listing01_10_1 {

	public static void main(String[] args) {
		// This is to show Syntax Errors
		// Just Remove one " 
		System.out.println("Hello World");
	}

}
