
public class Exercise01_11 {

	public static void main(String[] args) 
	{
			int population = 321032486;
			double birthsPerDay = 12384;
			double deathsPerDay = 6624;
			double immPerDay = 1872;
		
			System.out.println(population + (birthsPerDay * 365)+ (immPerDay * 365) - (deathsPerDay * 365)  );
			System.out.println( (population) + ((birthsPerDay * 365)+ (immPerDay * 365) - (deathsPerDay * 365) * 2) );
			System.out.println( (population) + ((birthsPerDay * 365)+ (immPerDay * 365) - (deathsPerDay * 365) * 3) );
			System.out.println( (population) + ((birthsPerDay * 365)+ (immPerDay * 365) - (deathsPerDay * 365) * 4) );
			System.out.println( (population) + ((birthsPerDay * 365)+ (immPerDay * 365) - (deathsPerDay * 365) * 5) );
			
	}

}
