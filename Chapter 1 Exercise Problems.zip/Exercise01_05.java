
public class Exercise01_05 {

	public static void main(String[] args) 
	{
		double top = (9.5 * 4.5) - (2.5 * 3);
		double bottom = 45.5 - 3.5;
		double sum = top / bottom;
		
		System.out.println("9.5 * 4.5 - 2.5 * 3 / 45.5 - 3.5 = " + sum);
		
		
	
	}

}
