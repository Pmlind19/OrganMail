
public class Exercise01_10 {

	public static void main(String[] args) 
	{
		double hour = 45.5/60;
		double mph = (14 / 1.6) / hour;
		System.out.println("If a runner runs 14Km in 45 minutes and 30 seconds he is running an average of " + mph + " miles per hour");

	}

}
