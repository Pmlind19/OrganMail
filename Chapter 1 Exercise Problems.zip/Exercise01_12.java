
public class Exercise01_12 {

	public static void main(String[] args) 
	{
		double hour = 60.66/60;
		double kmph = (24 * 1.6) / hour;
		System.out.println("A runner who can run 24 miles in 1 and 40 minutes runs about " + kmph + " Km per hour.");

	}

}
